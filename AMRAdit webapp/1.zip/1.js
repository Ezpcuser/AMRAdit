// Initialize Firebase (replace with your config)
const firebaseConfig = {
    apiKey: "YOUR_API_KEY",
    authDomain: "YOUR_AUTH_DOMAIN",
    projectId: "YOUR_PROJECT_ID",
    storageBucket: "YOUR_STORAGE_BUCKET",
    messagingSenderId: "YOUR_SENDER_ID",
    appId: "YOUR_APP_ID"
};

firebase.initializeApp(firebaseConfig);
const db = firebase.firestore();
const storage = firebase.storage();

// DOM elements
const viewMenuBtn = document.getElementById('viewMenuBtn');
const manageMenuBtn = document.getElementById('manageMenuBtn');
const menuView = document.getElementById('menuView');
const manageView = document.getElementById('manageView');
const menuCategories = document.getElementById('menuCategories');
const addCategoryForm = document.getElementById('addCategoryForm');
const addItemForm = document.getElementById('addItemForm');
const itemCategory = document.getElementById('itemCategory');
const currentMenu = document.getElementById('currentMenu');

// Switch between views
viewMenuBtn.addEventListener('click', () => {
    menuView.style.display = 'block';
    manageView.style.display = 'none';
    loadMenu();
});

manageMenuBtn.addEventListener('click', () => {
    menuView.style.display = 'none';
    manageView.style.display = 'block';
    loadCategoriesForDropdown();
    loadFullMenuForManagement();
});

// Add new category
addCategoryForm.addEventListener('submit', (e) => {
    e.preventDefault();
    const categoryName = document.getElementById('categoryName').value;
    
    db.collection('categories').add({
        name: categoryName,
        createdAt: firebase.firestore.FieldValue.serverTimestamp()
    }).then(() => {
        alert('Category added successfully!');
        addCategoryForm.reset();
        loadCategoriesForDropdown();
        loadFullMenuForManagement();
    }).catch(error => {
        console.error('Error adding category: ', error);
    });
});

// Add new menu item
addItemForm.addEventListener('submit', (e) => {
    e.preventDefault();
    
    const categoryId = itemCategory.value;
    const name = document.getElementById('itemName').value;
    const description = document.getElementById('itemDescription').value;
    const price = parseFloat(document.getElementById('itemPrice').value);
    const imageFile = document.getElementById('itemImage').files[0];
    
    if (imageFile) {
        // Upload image first
        const storageRef = storage.ref(`menu-items/${Date.now()}_${imageFile.name}`);
        storageRef.put(imageFile).then(snapshot => {
            return snapshot.ref.getDownloadURL();
        }).then(imageUrl => {
            return saveMenuItem(categoryId, name, description, price, imageUrl);
        }).then(() => {
            alert('Item added successfully with image!');
            addItemForm.reset();
            loadFullMenuForManagement();
        }).catch(error => {
            console.error('Error adding item: ', error);
        });
    } else {
        saveMenuItem(categoryId, name, description, price, '').then(() => {
            alert('Item added successfully!');
            addItemForm.reset();
            loadFullMenuForManagement();
        }).catch(error => {
            console.error('Error adding item: ', error);
        });
    }
});

function saveMenuItem(categoryId, name, description, price, imageUrl) {
    return db.collection('menuItems').add({
        categoryId: categoryId,
        name: name,
        description: description,
        price: price,
        imageUrl: imageUrl,
        createdAt: firebase.firestore.FieldValue.serverTimestamp()
    });
}

// Load categories for dropdown
function loadCategoriesForDropdown() {
    itemCategory.innerHTML = '<option value="">Select a category</option>';
    
    db.collection('categories').orderBy('name').get().then(querySnapshot => {
        querySnapshot.forEach(doc => {
            const option = document.createElement('option');
            option.value = doc.id;
            option.textContent = doc.data().name;
            itemCategory.appendChild(option);
        });
    });
}

// Load full menu for management view
function loadFullMenuForManagement() {
    currentMenu.innerHTML = '<h3>Current Menu</h3>';
    
    db.collection('categories').orderBy('name').get().then(categoriesSnapshot => {
        categoriesSnapshot.forEach(categoryDoc => {
            const categoryDiv = document.createElement('div');
            categoryDiv.className = 'menu-category';
            categoryDiv.innerHTML = `<h4>${categoryDoc.data().name}</h4>`;
            currentMenu.appendChild(categoryDiv);
            
            const itemsList = document.createElement('div');
            categoryDiv.appendChild(itemsList);
            
            db.collection('menuItems')
                .where('categoryId', '==', categoryDoc.id)
                .orderBy('name')
                .get()
                .then(itemsSnapshot => {
                    if (itemsSnapshot.empty) {
                        itemsList.innerHTML = '<p>No items in this category yet.</p>';
                    } else {
                        itemsSnapshot.forEach(itemDoc => {
                            const item = itemDoc.data();
                            const itemDiv = document.createElement('div');
                            itemDiv.className = 'menu-item';
                            itemDiv.innerHTML = `
                                ${item.imageUrl ? `<img src="${item.imageUrl}" alt="${item.name}">` : ''}
                                <div class="item-info">
                                    <h5>${item.name}</h5>
                                    <p>${item.description || ''}</p>
                                    <p class="item-price">$${item.price.toFixed(2)}</p>
                                </div>
                                <button class="delete-item" data-id="${itemDoc.id}">Delete</button>
                            `;
                            itemsList.appendChild(itemDiv);
                        });
                        
                        // Add event listeners to delete buttons
                        document.querySelectorAll('.delete-item').forEach(button => {
                            button.addEventListener('click', (e) => {
                                if (confirm('Are you sure you want to delete this item?')) {
                                    db.collection('menuItems').doc(e.target.dataset.id).delete()
                                        .then(() => {
                                            loadFullMenuForManagement();
                                        });
                                }
                            });
                        });
                    }
                });
        });
    });
}

// Load menu for public view
function loadMenu() {
    menuCategories.innerHTML = '';
    
    db.collection('categories').orderBy('name').get().then(categoriesSnapshot => {
        categoriesSnapshot.forEach(categoryDoc => {
            const categoryDiv = document.createElement('div');
            categoryDiv.className = 'menu-category';
            categoryDiv.innerHTML = `<h3>${categoryDoc.data().name}</h3>`;
            menuCategories.appendChild(categoryDiv);
            
            const itemsList = document.createElement('div');
            categoryDiv.appendChild(itemsList);
            
            db.collection('menuItems')
                .where('categoryId', '==', categoryDoc.id)
                .orderBy('name')
                .get()
                .then(itemsSnapshot => {
                    if (itemsSnapshot.empty) {
                        itemsList.innerHTML = '<p>Coming soon!</p>';
                    } else {
                        itemsSnapshot.forEach(itemDoc => {
                            const item = itemDoc.data();
                            const itemDiv = document.createElement('div');
                            itemDiv.className = 'menu-item';
                            itemDiv.innerHTML = `
                                ${item.imageUrl ? `<img src="${item.imageUrl}" alt="${item.name}">` : ''}
                                <div class="item-info">
                                    <h4>${item.name}</h4>
                                    <p>${item.description || ''}</p>
                                    <p class="item-price">$${item.price.toFixed(2)}</p>
                                </div>
                            `;
                            itemsList.appendChild(itemDiv);
                        });
                    }
                });
        });
    });
}

// Initialize the app
loadCategoriesForDropdown();
loadMenu();